package com.example.jiashuwu.neurograph;

/**
 * Created by Jiashu Wu on 28/03/2018.
 */

public class DatabaseInformation {

    public static String databaseName = "information.db";
    public static int databaseVersion = 7;

}
